<?php
//1. POSTデータ取得（index.phpのフォームからデータを受け取る）
$date = $_POST["date"];
$mountain_name = $_POST["mountain_name"];
$comment = $_POST["comment"];
$website_url = $_POST["website_url"];


//2. DB接続します
require "funcs.php"; //funcs.phpに書いた関数を呼び出す
$pdo = db_conn();

//３．データ登録SQL作成
$stmt = $pdo->prepare("INSERT INTO gs_bm_table(date,mountain_name,comment,website_url)VALUES(:date,:mountain_name,:comment,:website_url)");
$stmt->bindValue(':date', $date, PDO::PARAM_STR);  //Integer（数値の場合 PDO::PARAM_INT)
$stmt->bindValue(':mountain_name', $mountain_name, PDO::PARAM_STR);  
$stmt->bindValue(':comment', $comment, PDO::PARAM_STR);
$stmt->bindValue(':website_url', $website_url, PDO::PARAM_STR);
$status = $stmt->execute(); //実行

//４．データ登録処理後
if($status==false){
  sql_error($stmt);
}else{
  redirect("index.php");
}
?>
