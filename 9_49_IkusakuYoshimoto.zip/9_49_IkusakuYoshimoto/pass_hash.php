<?php

$hashpass = password_hash("pw3",PASSWORD_DEFAULT);

echo $hashpass; //ハッシュ化したパスワードをエコーする



?>