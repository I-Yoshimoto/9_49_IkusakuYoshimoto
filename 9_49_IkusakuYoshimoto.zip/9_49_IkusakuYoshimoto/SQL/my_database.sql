-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- ホスト: localhost:8889
-- 生成日時: 2020 年 7 月 02 日 23:33
-- サーバのバージョン： 5.7.26
-- PHP のバージョン: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `my_database`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `gs_bm_table`
--

CREATE TABLE `gs_bm_table` (
  `id` int(12) NOT NULL,
  `date` date NOT NULL,
  `mountain_name` varchar(64) NOT NULL,
  `comment` text NOT NULL,
  `website_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `gs_bm_table`
--

INSERT INTO `gs_bm_table` (`id`, `date`, `mountain_name`, `comment`, `website_url`) VALUES
(8, '2011-08-16', '槍ヶ岳', '今回は上高地から一日で登った。\r\n夕方はピークも空いていたので、明日向かう穂高の方を眺めながら、のんびり過ごした!!!!!!!!\r\n', 'https://www.yarigatake.co.jp/yarigatake/'),
(9, '2011-08-14', '北穂高岳', '南岳から眺める大キレット越しの北穂高岳は、北アルプスで一番カッコいい景色で、ようやく辿り着いた北穂高小屋のテラスは最高だった。\r\n流れる雲の間から見え隠れする常念岳を見つめる一時。', 'http://www.kitaho.co.jp/'),
(10, '2012-10-12', '剱岳', '事前に映画　「剱岳 点の記」 を観て、登るのが本当に楽しみだった。\r\n別山尾根は予想していたよりもホールドがしっかりしていたが、下山のヨコバイでは足が届かない場所があり、仕方なく鎖に全体重をかけることになった。\r\nこの日は天気が悪くて頂上から何も見えなかったが、翌日は快晴に恵まれて、紅葉に彩られた剱岳をしっかり目に焼き付けて、剱沢小屋を後にした。', 'http://home.384.jp/tsuruqi1/'),
(14, '2020-06-18', '筑波山', '標高は低いがなかなか楽しめる山だった。\r\n頂上からは僅かに富士山が見えた。', 'https://www.mt-tsukuba.com/'),
(16, '2020-06-19', '陣馬山', '近場の縦走路としては悪くない。\r\n帰りは藤野駅からのんびり帰る・・・。', 'https://info-fujino.com/hiking/224.html'),
(21, '2020-06-28', '塔ノ岳', '晴れていれば、頂上から富士山が良く見える☆', 'https://www.kankou-hadano.org/hadano_mountain/mountain_tnd.html');

-- --------------------------------------------------------

--
-- テーブルの構造 `gs_user_table`
--

CREATE TABLE `gs_user_table` (
  `id` int(12) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `lid` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `lpw` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kanri_flg` int(1) NOT NULL,
  `life_flg` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `gs_user_table`
--

INSERT INTO `gs_user_table` (`id`, `name`, `lid`, `lpw`, `kanri_flg`, `life_flg`) VALUES
(1, '吉本郁作', 'id1', '$2y$10$BaC0xGYtHaHiQZ5VatrDcevEiowdCoC/q4Ht42hyXw5AzYVOSLjjK', 1, 0),
(2, '山田太郎', 'id2', '$2y$10$jgoxcQHLeXU7LtmHMB1.xOz4zaz57Gq4V7yjI0sAZ48j5G1hv1g3i', 0, 0),
(3, '山田花子', 'id3', '$2y$10$3AUXSM3AB8YCIEDeXe4XR.WURNKWOHCLH70lisLqM8GH.ZfmNx29S', 0, 0);

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `gs_bm_table`
--
ALTER TABLE `gs_bm_table`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `gs_user_table`
--
ALTER TABLE `gs_user_table`
  ADD PRIMARY KEY (`id`);

--
-- ダンプしたテーブルのAUTO_INCREMENT
--

--
-- テーブルのAUTO_INCREMENT `gs_bm_table`
--
ALTER TABLE `gs_bm_table`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- テーブルのAUTO_INCREMENT `gs_user_table`
--
ALTER TABLE `gs_user_table`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
