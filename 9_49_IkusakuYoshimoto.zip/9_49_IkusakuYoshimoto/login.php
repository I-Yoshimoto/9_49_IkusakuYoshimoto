<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>ログイン</title>
  <meta name="viewport" content="width=device-width">
  <!-- <link rel="stylesheet" href="css/main.css" />
  <link href="css/bootstrap.min.css" rel="stylesheet"> -->
  <link rel="stylesheet" href="css/reset.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
  <div class="login_header_container">
    <h1 class="login_heading">▲ 山行記録サイト</h1>
    <p class="login_subheading">〜登った山をメモしよう〜</p>
    <a class="top_page" href="index.php">トップページへ</a>
  </div>

  </div>
 
</header>

    <!-- login_act.phpに「post」でデータを送る -->
  <form name="form1" action="login_act.php" method="post" class="login_form">
      ID: <input type="text" name="lid" class="id" />
      PW: <input type="password" name="lpw" class="password" />
      <input type="submit" value="ログイン" />
  </form>

<div class="index_img_container">
    <img class="login_view_img" src="img/sample-img_01.jpg">   
    <img class="login_view_img" src="img/sample-img_02.jpg">  
    <img class="login_view_img" src="img/sample-img_03.jpg">  
    <img class="login_view_img" src="img/sample-img_04.jpeg">  
    <!-- <img class="login_view_img" src="img/sample-img_05.jpg">   -->
</div>

</body>
</html>